import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';

function Cube({ mouse }) {
  const mesh = useRef();

  useFrame(({ clock }) => {
    if (mesh.current) {
      // Floating effect using sine wave
      mesh.current.position.y = Math.sin(clock.getElapsedTime() * 2) * 0.3;
      // Rotate to look at pointer
      mesh.current.rotation.y = mouse.x * 0.3;
      mesh.current.rotation.x = mouse.y * 0.3;
    }
  });

  return (
    <mesh ref={mesh}>
      <boxGeometry args={[2, 2, 2]} />
      <meshStandardMaterial color="#D3FB43" />
    </mesh>
  );
}

export default function CenterCube() {
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  // Get mouse position relative to center
  const handleMouseMove = (e) => {
    const rect = e.target.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
    setMouse({ x, y });
  };

  return (
    <div
      className="absolute inset-0 flex items-center justify-center z-30 pointer-events-auto"
      style={{ width: '100vw', height: '100vh' }}
      onMouseMove={handleMouseMove}
    >
      <Canvas style={{ width: '100%', height: '100%' }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[2, 2, 5]} />
        <Cube mouse={mouse} />
      </Canvas>
    </div>
  );
}