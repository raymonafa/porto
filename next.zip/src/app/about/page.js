// src/app/about/page.js
export default function AboutPage() {
  return (
    <main className="min-h-screen bg-[#f8f8f8] text-black pb-24">
      <section className="pt-24 px-6">
        About Page
      </section>
    </main>
  );
}
