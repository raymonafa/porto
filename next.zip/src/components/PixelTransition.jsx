"use client";

import React, {
  forwardRef,
  useImperativeHandle,
  useMemo,
  useRef,
  useEffect,
} from "react";
import gsap from "gsap";

function makeCells(container, { pixelSize, color }) {
  // bersihkan isi lama
  while (container.firstChild) container.removeChild(container.firstChild);

  const vw = Math.ceil(window.innerWidth / pixelSize);
  const vh = Math.ceil(window.innerHeight / pixelSize);

  // pakai CSS grid biar ringan
  Object.assign(container.style, {
    display: "grid",
    gridTemplateColumns: `repeat(${vw}, ${pixelSize}px)`,
    gridTemplateRows: `repeat(${vh}, ${pixelSize}px)`,
    gap: "0px",
  });

  const cells = [];
  const total = vw * vh;
  for (let i = 0; i < total; i++) {
    const d = document.createElement("div");
    d.style.width = `${pixelSize}px`;
    d.style.height = `${pixelSize}px`;
    d.style.background = color;
    d.style.willChange = "transform, opacity";
    container.appendChild(d);
    cells.push(d);
  }
  return { cells, grid: [vh, vw] }; // urutan: [rows, cols]
}

const PixelTransition = forwardRef(
  (
    {
      pixelSize = 80,      // ukuran tile
      color = "#D3FB43",    // warna cover (sesuaikan tema)
      coverDuration = 1, // durasi nutup
      revealDuration = 1 // durasi buka
    },
    ref
  ) => {
    const wrapRef = useRef(null);
    const gridRef = useRef(null);
    const tlRef = useRef(null);

    // pastikan container fixed dan di atas segalanya
    useEffect(() => {
      const wrap = wrapRef.current;
      if (!wrap) return;
      Object.assign(wrap.style, {
        position: "fixed",
        inset: "0",
        zIndex: "999999",
        pointerEvents: "none",
        display: "none", // idle = tidak terlihat
      });
      const grid = gridRef.current;
      Object.assign(grid.style, {
        width: "100%",
        height: "100%",
        pointerEvents: "none",
      });
    }, []);

    useImperativeHandle(ref, () => ({
      /**
       * Mulai transisi:
       * 1) COVER: tile scale 0 -> 1 (random stagger)
       * 2) onCovered(): panggil router.push di TransitionShell
       * 3) REVEAL: tile scale 1 -> 0 (random stagger)
       * 4) dispatch "app:transition:reveal:done"
       */
      play(onCovered) {
        const wrap = wrapRef.current;
        const grid = gridRef.current;
        if (!wrap || !grid) return;

        // kill tl lama jika ada
        if (tlRef.current) {
          tlRef.current.kill();
          tlRef.current = null;
        }

        // siapkan grid sesuai viewport saat ini
        const { cells, grid: dims } = makeCells(grid, { pixelSize, color });

        // tampilkan overlay
        wrap.style.display = "block";

        // state awal: scale(0)
        gsap.set(cells, { scale: 0, transformOrigin: "center center" });

        // COVER
        const tl = gsap.timeline({
          defaults: { ease: "power4.inOut" },
        });

        tl.to(cells, {
          scale: 1,
          duration: coverDuration,
          stagger: {
            // random biar natural dan ringan
            each: (coverDuration / Math.max(1, cells.length)) * 32,
            grid: dims, // [rows, cols]
            from: "random",
          },
          onComplete: () => {
            // panggil callback untuk navigate
            try { onCovered?.(); } catch {}
            // REVEAL setelah konten baru mount (tunggu 2 raf)
            requestAnimationFrame(() => {
              requestAnimationFrame(() => {
                // pastikan tetap visible selama reveal
                wrap.style.display = "block";

                // state awal untuk REVEAL sudah scale:1,
                // tinggal animasikan ke 0 lagi
                gsap.to(cells, {
                  scale: 0,
                  duration: revealDuration,
                  stagger: {
                    each: (revealDuration / Math.max(1, cells.length)) * 32,
                    grid: dims,
                    from: "random",
                  },
                  ease: "power4.inOut",
                  onComplete: () => {
                    // sembunyikan overlay dan bersih-bersih
                    wrap.style.display = "none";
                    while (grid.firstChild) grid.removeChild(grid.firstChild);
                    // 🔔 Beritahu halaman: reveal selesai
                    window.dispatchEvent(
                      new Event("app:transition:reveal:done")
                    );
                  },
                });
              });
            });
          },
        });

        tlRef.current = tl;
      },
    }));

    return (
      <div ref={wrapRef} aria-hidden>
        <div ref={gridRef} />
      </div>
    );
  }
);

export default PixelTransition;
